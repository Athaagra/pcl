#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 19:40:08 2022

@author: kel
"""

from pymongo import MongoClient
from flask import Flask, render_template, request, redirect, url_for, abort
#from werkzeg.utils import secure_filename
import os
import datetime
import numpy as np
app = Flask(__name__)

app.config['MAX_CONTENT_LENGTH']=1024*1024
app.config['UPLOAD_EXTENSIONS']=['.jpg','.png','.gif']
app.config['UPLOAD_PATH']='uploads'

def UserExist(username):
    client= MongoClient('localhost', 27017)
    db= client.localdb
    if db.users.find({"name":username}).count()==0:
        return False
    else:
        db.users.update_many({'name':username},{'$set':{'Userfiles':'N'}})
        return True


#@app.route('/')
#def bst():
#    return render_template('bst.html')

@app.route('/result', methods=['POST','GET'])
def result():
    if request.method=='POST':
        result=request.form
        res=list(result.values())
        if UserExist(res[0])==True:
            return render_template('result.html',result=result)
        else:
            return render_template('userno.html')

@app.route('/')
def index():
    client= MongoClient('localhost', 27017)
    db= client.localdb
    db.users.insert_one({'name':'bobby','file':'hchff','date':'empty','Userfiles':'y'})
    db.users.insert_one({'name':'kay','file':'gvgv','date':'empty','Userfiles':'y'})
    db.users.insert_one({'name':'john','file':'aewwaez','date':'empty','Userfiles':'y'})
    files=[]
    file=db.users.find({"Userfiles":'N'})
    file=np.array(file)
    files.append(file)
    print('Homepage files {}'.format(files))
    #print('Number of files:{}'.format(len(files)))
    if len(files)<1:
        return render_template('bst.html')
    else:
        db.users.update_many({'Userfiles':'N'},{'$set':{'Userfiles':'y'}})
        return render_template('indexu.html',files=files)

@app.route('/', methods=['POST','GET'])
def upload_file():
    files=[]
    client= MongoClient('localhost', 27017)
    db= client.localdb
    if request.method=='POST':
        uploaded_file = request.files['file']
        filename = uploaded_file
        fl=str(filename)
        file_extention='.'+fl[-6:-3]
        if file_extention != '':
            if file_extention not in app.config['UPLOAD_EXTENSIONS']:
                #abort(400)# uploaded_file.filename !='':
                return render_template('bst.html') 
            uploaded_file.save(uploaded_file.filename)
            formatted_date = datetime.datetime.today().strftime("%Y-%m-%d")
            files.append(uploaded_file.filename)
            print('Those are files:{}'.format(files))
            db.users.update_many({'Userfiles':'N'},{'$set':{'file':files,'date':formatted_date}})
        return redirect(url_for('index'))
    #return render_template('indexu.html',files=files)



if __name__=="__main__":
    app.run(host="127.0.0.1",port=80,debug=True)
    #fol,index=upload_file()